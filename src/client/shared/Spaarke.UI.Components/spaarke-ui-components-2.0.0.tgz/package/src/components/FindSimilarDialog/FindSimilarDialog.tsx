/**
 * FindSimilarDialog - Reusable iframe dialog for the DocumentRelationshipViewer.
 *
 * Renders a near-fullscreen Dialog containing an iframe that loads the
 * DocumentRelationshipViewer Code Page web resource.
 *
 * Consumer builds the URL (since URL construction differs between PCF and
 * LegalWorkspace) and passes it in. This component just provides the dialog
 * shell with correct sizing and no scrollbars.
 *
 * Optional `embedded` prop hides the title bar chrome when the dialog is
 * rendered inside a Dataverse form (e.g., as part of a PCF control panel).
 *
 * Optional `authenticatedFetch` and `bffBaseUrl` are accepted for forward
 * compatibility with service-injected patterns but are not currently used
 * by the iframe shell itself.
 *
 * Zero hard service dependencies — fully prop-based.
 *
 * @see ADR-021 for Fluent UI v9 requirements
 * @see ADR-012 for shared component library patterns
 */

import * as React from 'react';
import {
  makeStyles,
  tokens,
  Dialog,
  DialogSurface,
  DialogBody,
  Button,
  Text,
  Tooltip,
  shorthands,
} from '@fluentui/react-components';
import { DismissRegular, ArrowExpandRegular } from '@fluentui/react-icons';

import type { IDataService } from '../../types/serviceInterfaces';

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

export interface IFindSimilarDialogProps {
  /** Whether the dialog is open. */
  open: boolean;
  /** Called when the dialog requests to close (backdrop click, Escape). */
  onClose: () => void;
  /** The URL to load in the iframe. When null/undefined the iframe is not rendered. */
  url: string | null;
  /**
   * When true, hides the title bar chrome (expand / close buttons).
   * Useful when the dialog is rendered inside a Dataverse form where
   * the parent already provides navigation controls.
   * @default false
   */
  embedded?: boolean;
  /**
   * Optional authenticated fetch function for forward compatibility
   * with service-injection patterns. Not used by the iframe shell itself.
   */
  authenticatedFetch?: (url: string, init?: RequestInit) => Promise<Response>;
  /**
   * Optional BFF API base URL for forward compatibility with
   * service-injection patterns. Not used by the iframe shell itself.
   */
  bffBaseUrl?: string;
  /**
   * Optional data service for forward compatibility with service-injection
   * patterns. Not used by the iframe shell itself, but available for
   * consumers that may extend this component.
   */
  dataService?: IDataService;
}

// ---------------------------------------------------------------------------
// Styles
// ---------------------------------------------------------------------------

const useStyles = makeStyles({
  surface: {
    padding: '0px',
    width: '85vw',
    maxWidth: '85vw',
    height: '85vh',
    maxHeight: '85vh',
    display: 'flex',
    flexDirection: 'column',
    ...shorthands.overflow('hidden'),
    ...shorthands.borderRadius(tokens.borderRadiusXLarge),
  },
  titleBar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: tokens.spacingHorizontalXS,
    paddingTop: tokens.spacingVerticalXS,
    paddingRight: tokens.spacingHorizontalS,
    paddingBottom: tokens.spacingVerticalXS,
    paddingLeft: tokens.spacingHorizontalS,
    backgroundColor: tokens.colorNeutralBackground3,
    borderBottom: `1px solid ${tokens.colorNeutralStroke2}`,
    flexShrink: 0,
  },
  body: {
    padding: '0px',
    flex: 1,
    minHeight: 0,
    position: 'relative' as const,
  },
  frame: {
    position: 'absolute' as const,
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    border: 'none',
    display: 'block',
  },
});

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export const FindSimilarDialog: React.FC<IFindSimilarDialogProps> = ({
  open,
  onClose,
  url,
  embedded = false,
}) => {
  const styles = useStyles();

  const handleExpand = React.useCallback(() => {
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  }, [url]);

  return (
    <Dialog
      open={open}
      onOpenChange={(_, data) => {
        if (!data.open) onClose();
      }}
    >
      <DialogSurface className={styles.surface}>
        {!embedded && (
          <div className={styles.titleBar}>
            <Text weight="semibold" size={400}>Similar Documents</Text>
            <div style={{ display: 'flex', alignItems: 'center', gap: tokens.spacingHorizontalXS }}>
              <Tooltip content="Open in new tab" relationship="label">
                <Button
                  appearance="subtle"
                  icon={<ArrowExpandRegular />}
                  size="small"
                  onClick={handleExpand}
                  aria-label="Open in new tab"
                />
              </Tooltip>
              <Tooltip content="Close" relationship="label">
                <Button appearance="subtle" icon={<DismissRegular />} size="small" onClick={onClose} aria-label="Close" />
              </Tooltip>
            </div>
          </div>
        )}
        <DialogBody className={styles.body}>
          {url && <iframe src={url} title="Document Relationships" className={styles.frame} />}
        </DialogBody>
      </DialogSurface>
    </Dialog>
  );
};

export default FindSimilarDialog;
