/**
 * AI Summary Orchestration Hook (useAiSummary)
 *
 * Manages AI document analysis for multiple documents with concurrent streaming,
 * status tracking, and batch enqueue on close. Updated for the Document Intelligence
 * API which returns structured analysis results (summary, TL;DR, keywords, entities).
 *
 * @version 2.0.0.0
 */

import { useState, useCallback, useRef, useEffect } from 'react';

/**
 * Extracted entities from document analysis
 */
export interface ExtractedEntities {
  /** Organizations mentioned in the document */
  organizations: string[];
  /** People mentioned in the document */
  people: string[];
  /** Monetary amounts or quantities */
  amounts: string[];
  /** Dates or time periods */
  dates: string[];
  /** Document type classification */
  documentType: string;
  /** Reference numbers (invoice, PO, case numbers, etc.) */
  references: string[];
}

/**
 * Complete result of AI document analysis
 */
export interface DocumentAnalysisResult {
  /** Multi-sentence summary */
  summary: string;
  /** TL;DR bullet points (1-3 items) */
  tldr: string[];
  /** Comma-separated keywords */
  keywords: string;
  /** Extracted named entities */
  entities: ExtractedEntities;
  /** Raw AI response (for debugging) */
  rawResponse?: string;
  /** Whether parsing was successful */
  parsedSuccessfully: boolean;
}

/**
 * Summary status types
 */
export type SummaryStatus = 'pending' | 'streaming' | 'complete' | 'error' | 'skipped' | 'not-supported';

/**
 * Document summary state for tracking and display
 */
export interface DocumentSummaryState {
  /** Document identifier */
  documentId: string;
  /** File name */
  fileName: string;
  /** Summary text (may be partial during streaming) */
  summary?: string;
  /** Current status */
  status: SummaryStatus;
  /** Error message (when status is 'error') */
  error?: string;
  /** TL;DR bullet points (available after completion) */
  tldr?: string[];
  /** Keywords (available after completion) */
  keywords?: string;
  /** Extracted entities (available after completion) */
  entities?: ExtractedEntities;
  /** Document type classification (available after completion) */
  documentType?: string;
  /** Whether structured parsing was successful */
  parsedSuccessfully?: boolean;
  /** Analysis ID from Dataverse (available after completion) */
  analysisId?: string;
  /** Whether storage partially succeeded (outputs saved but field mapping failed) */
  partialStorage?: boolean;
  /** User-friendly message about storage result */
  storageMessage?: string;
}

/**
 * Document to be summarized
 */
export interface SummaryDocument {
  /** Unique document ID (Dataverse GUID) */
  documentId: string;

  /** SharePoint Embedded drive ID */
  driveId: string;

  /** SharePoint Embedded item ID */
  itemId: string;

  /** File name for display */
  fileName: string;
}

/**
 * Hook configuration options
 */
export interface UseAiSummaryOptions {
  /** Base URL for API endpoints */
  apiBaseUrl: string;

  /** Function to get authorization token (for dynamic token acquisition) */
  getToken?: () => Promise<string>;

  /** Maximum concurrent streams (default: 3) */
  maxConcurrent?: number;

  /** Auto-start streaming when documents added */
  autoStart?: boolean;

  /** Callback when analysis completes successfully */
  onAnalysisComplete?: (documentId: string, result: DocumentAnalysisResult) => void;

  /** @deprecated Use onAnalysisComplete instead */
  onSummaryComplete?: (documentId: string, summary: string) => void;
}

/**
 * Hook return type
 */
export interface UseAiSummaryResult {
  /** Document summary states for carousel display */
  documents: DocumentSummaryState[];

  /** Whether any summaries are in progress */
  isProcessing: boolean;

  /** Count of completed summaries */
  completedCount: number;

  /** Count of documents with errors */
  errorCount: number;

  /** Add documents to be summarized */
  addDocuments: (docs: SummaryDocument[]) => void;

  /** Start streaming for all pending documents */
  startAll: () => void;

  /** Retry a specific document */
  retry: (documentId: string) => void;

  /** Enqueue incomplete summaries for background processing */
  enqueueIncomplete: () => Promise<void>;

  /** Clear all documents */
  clear: () => void;

  /** Check if there are incomplete summaries */
  hasIncomplete: boolean;
}

/**
 * Internal state for tracking active streams
 */
interface StreamState {
  abortController: AbortController;
  documentId: string;
}

/**
 * SSE chunk from Document Intelligence API
 */
interface SseChunk {
  /** Event type: "text" | "complete" | "error" */
  type?: string;
  /** Content for streaming text chunks */
  content?: string;
  /** Whether this is the final chunk */
  done?: boolean;
  /** Summary text (legacy, for backward compatibility) */
  summary?: string;
  /** Structured analysis result (for type="complete") */
  result?: DocumentAnalysisResult;
  /** Error message (for type="error") */
  error?: string;
  /** Analysis ID from Dataverse */
  analysisId?: string;
  /** Whether storage partially succeeded (soft failure) */
  partialStorage?: boolean;
  /** User-friendly message about storage result */
  storageMessage?: string;
}

/**
 * Parse SSE line to extract data
 */
const parseSseLine = (line: string): SseChunk | null => {
  const trimmed = line.trim();
  if (!trimmed || trimmed.startsWith(':')) return null;

  if (trimmed.startsWith('data:')) {
    const jsonStr = trimmed.slice(5).trim();
    if (!jsonStr || jsonStr === '[DONE]') {
      return { done: true };
    }
    try {
      return JSON.parse(jsonStr) as SseChunk;
    } catch {
      return { content: jsonStr };
    }
  }
  return null;
};

/**
 * useAiSummary Hook
 *
 * Orchestrates AI document analysis for multiple documents with
 * concurrent streaming and status management.
 */
export const useAiSummary = (options: UseAiSummaryOptions): UseAiSummaryResult => {
  const { apiBaseUrl, getToken, maxConcurrent = 3, autoStart = true, onAnalysisComplete, onSummaryComplete } = options;

  const [documents, setDocuments] = useState<DocumentSummaryState[]>([]);
  const activeStreamsRef = useRef<Map<string, StreamState>>(new Map());
  const pendingQueueRef = useRef<SummaryDocument[]>([]);
  const documentMapRef = useRef<Map<string, SummaryDocument>>(new Map());

  /**
   * Update a single document's state
   */
  const updateDocument = useCallback((documentId: string, updates: Partial<DocumentSummaryState>) => {
    setDocuments(prev => prev.map(doc => (doc.documentId === documentId ? { ...doc, ...updates } : doc)));
  }, []);

  /**
   * Stream document analysis for a single document
   */
  const streamDocument = useCallback(
    async (doc: SummaryDocument) => {
      const { documentId, driveId, itemId } = doc;

      console.log('[useAiSummary] Starting stream for document:', {
        documentId,
        driveId,
        itemId,
        apiBaseUrl,
      });

      // Check if already streaming
      if (activeStreamsRef.current.has(documentId)) {
        console.log('[useAiSummary] Already streaming, skipping:', documentId);
        return;
      }

      // Create abort controller
      const abortController = new AbortController();
      activeStreamsRef.current.set(documentId, { abortController, documentId });

      // Update status to streaming
      updateDocument(documentId, {
        status: 'streaming',
        summary: '',
        error: undefined,
      });

      let accumulatedSummary = '';

      // Helper function to get token headers
      const getAuthHeaders = async (): Promise<Record<string, string>> => {
        if (!getToken) return {};
        try {
          const token = await getToken();
          console.log('[useAiSummary] Token acquired successfully');
          return { Authorization: `Bearer ${token}` };
        } catch (tokenError) {
          console.error('[useAiSummary] Failed to acquire token:', tokenError);
          throw new Error('Failed to acquire authentication token');
        }
      };

      try {
        // Step 1: Resolve Document Profile playbook
        let playbookId: string;
        try {
          const playbookUrl = `${apiBaseUrl}/api/ai/playbooks/by-name/Document%20Profile`;
          const authHeaders = await getAuthHeaders();
          const playbookResponse = await fetch(playbookUrl, {
            method: 'GET',
            headers: {
              Accept: 'application/json',
              ...authHeaders,
            },
            signal: abortController.signal,
          });

          if (!playbookResponse.ok) {
            throw new Error(`Failed to resolve playbook: HTTP ${playbookResponse.status}`);
          }

          const playbook = await playbookResponse.json();
          playbookId = playbook.playbookId || playbook.id;
          console.log('[useAiSummary] Resolved Document Profile playbook:', playbookId);
        } catch (playbookError) {
          console.error('[useAiSummary] Failed to resolve playbook:', playbookError);
          throw new Error('Failed to resolve Document Profile playbook');
        }

        // Step 2: Execute analysis with new unified endpoint
        const streamUrl = `${apiBaseUrl}/api/ai/analysis/execute`;
        console.log('[useAiSummary] Fetching:', streamUrl);

        const authHeaders = await getAuthHeaders();

        const response = await fetch(streamUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'text/event-stream',
            ...authHeaders,
          },
          body: JSON.stringify({
            documentIds: [documentId], // Array for multi-document support
            playbookId: playbookId,
            actionId: null, // Use playbook's default action
            additionalContext: null,
          }),
          signal: abortController.signal,
        });

        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(errorText || `HTTP ${response.status}`);
        }

        if (!response.body) {
          throw new Error('Response body not readable');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();

          if (done) {
            // Stream ended without complete event - mark as complete with accumulated data
            updateDocument(documentId, { status: 'complete' });
            if (onSummaryComplete && accumulatedSummary) {
              onSummaryComplete(documentId, accumulatedSummary);
            }
            break;
          }

          buffer += decoder.decode(value, { stream: true });
          const events = buffer.split('\n\n');
          buffer = events.pop() || '';

          for (const event of events) {
            for (const line of event.split('\n')) {
              const chunk = parseSseLine(line);
              if (chunk) {
                // Handle error event
                if (chunk.type === 'error' || chunk.error) {
                  throw new Error(chunk.error || 'Unknown error');
                }

                // Handle metadata event (analysisId, documentName)
                if (chunk.type === 'metadata') {
                  if (chunk.analysisId) {
                    updateDocument(documentId, {
                      analysisId: chunk.analysisId,
                    });
                    console.log('[useAiSummary] Analysis ID:', chunk.analysisId);
                  }
                  continue;
                }

                // Handle done event (analysis complete)
                if (chunk.type === 'done' || chunk.done) {
                  const updates: Partial<DocumentSummaryState> = {
                    status: 'complete',
                    summary: accumulatedSummary,
                  };

                  // Add analysis metadata
                  if (chunk.analysisId) {
                    updates.analysisId = chunk.analysisId;
                  }

                  // Add storage result metadata (soft failure handling)
                  if (chunk.partialStorage !== undefined) {
                    updates.partialStorage = chunk.partialStorage;
                  }
                  if (chunk.storageMessage) {
                    updates.storageMessage = chunk.storageMessage;
                  }

                  // Legacy callback for backward compatibility
                  if (onSummaryComplete && updates.summary) {
                    onSummaryComplete(documentId, updates.summary);
                  }

                  updateDocument(documentId, updates);
                  activeStreamsRef.current.delete(documentId);
                  console.log('[useAiSummary] Analysis complete:', {
                    analysisId: chunk.analysisId,
                    partialStorage: chunk.partialStorage,
                    storageMessage: chunk.storageMessage,
                  });
                  return;
                }

                // Handle streaming text content (type="chunk")
                if (chunk.type === 'chunk' || chunk.content) {
                  accumulatedSummary += chunk.content || '';
                  updateDocument(documentId, { summary: accumulatedSummary });
                }
              }
            }
          }
        }
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          // Aborted - don't update to error
          return;
        }

        updateDocument(documentId, {
          status: 'error',
          error: err instanceof Error ? err.message : 'Unknown error',
        });
      } finally {
        activeStreamsRef.current.delete(documentId);
        // Process next in queue
        processQueue();
      }
    },
    [apiBaseUrl, getToken, updateDocument, onAnalysisComplete, onSummaryComplete]
  );

  /**
   * Process pending queue respecting concurrent limit
   */
  const processQueue = useCallback(() => {
    const activeCount = activeStreamsRef.current.size;
    const availableSlots = maxConcurrent - activeCount;

    if (availableSlots <= 0 || pendingQueueRef.current.length === 0) {
      return;
    }

    const toProcess = pendingQueueRef.current.splice(0, availableSlots);
    toProcess.forEach(doc => streamDocument(doc));
  }, [maxConcurrent, streamDocument]);

  /**
   * Add documents to be summarized
   */
  const addDocuments = useCallback(
    (docs: SummaryDocument[]) => {
      console.log('[useAiSummary] addDocuments called with:', docs.length, 'documents', docs);

      // Add to document map
      docs.forEach(doc => documentMapRef.current.set(doc.documentId, doc));

      // Create initial states
      const newStates: DocumentSummaryState[] = docs.map(doc => ({
        documentId: doc.documentId,
        fileName: doc.fileName,
        status: 'pending' as SummaryStatus,
        summary: undefined,
        error: undefined,
        tldr: undefined,
        keywords: undefined,
        entities: undefined,
        documentType: undefined,
        parsedSuccessfully: undefined,
        analysisId: undefined,
        partialStorage: undefined,
        storageMessage: undefined,
      }));

      setDocuments(prev => [...prev, ...newStates]);

      // Add to pending queue
      pendingQueueRef.current.push(...docs);

      // Auto-start if enabled
      if (autoStart) {
        // Use setTimeout to ensure state is updated
        setTimeout(() => processQueue(), 0);
      }
    },
    [autoStart, processQueue]
  );

  /**
   * Start streaming for all pending documents
   */
  const startAll = useCallback(() => {
    processQueue();
  }, [processQueue]);

  /**
   * Retry a specific document
   */
  const retry = useCallback(
    (documentId: string) => {
      const doc = documentMapRef.current.get(documentId);
      if (!doc) return;

      // Reset status to pending and clear all fields
      updateDocument(documentId, {
        status: 'pending',
        summary: undefined,
        error: undefined,
        tldr: undefined,
        keywords: undefined,
        entities: undefined,
        documentType: undefined,
        parsedSuccessfully: undefined,
        analysisId: undefined,
        partialStorage: undefined,
        storageMessage: undefined,
      });

      // Add back to queue
      pendingQueueRef.current.push(doc);
      processQueue();
    },
    [updateDocument, processQueue]
  );

  /**
   * Enqueue incomplete summaries for background processing
   * @deprecated Background AI analysis has been removed. AI analysis now requires user context (OBO authentication).
   * This method is a no-op and exists only for backward compatibility.
   */
  const enqueueIncomplete = useCallback(async () => {
    console.warn(
      '[useAiSummary] enqueueIncomplete is deprecated. Background AI analysis has been removed. Users must trigger analysis manually.'
    );
    // No-op: Background job processing has been removed per ARCHITECTURE-CHANGES.md
    // The DocumentIntelligenceService and enqueue-batch endpoint no longer exist
    // AI analysis now requires user context (OBO authentication) and cannot run as background job
  }, []);

  /**
   * Clear all documents
   */
  const clear = useCallback(() => {
    // Abort all active streams
    activeStreamsRef.current.forEach(({ abortController }) => {
      abortController.abort();
    });
    activeStreamsRef.current.clear();

    // Clear queues
    pendingQueueRef.current = [];
    documentMapRef.current.clear();

    // Clear state
    setDocuments([]);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      activeStreamsRef.current.forEach(({ abortController }) => {
        abortController.abort();
      });
    };
  }, []);

  // Computed values
  const isProcessing = documents.some(d => d.status === 'streaming' || d.status === 'pending');
  const completedCount = documents.filter(d => d.status === 'complete').length;
  const errorCount = documents.filter(d => d.status === 'error').length;
  const hasIncomplete = documents.some(
    d => d.status !== 'complete' && d.status !== 'skipped' && d.status !== 'not-supported'
  );

  return {
    documents,
    isProcessing,
    completedCount,
    errorCount,
    addDocuments,
    startAll,
    retry,
    enqueueIncomplete,
    clear,
    hasIncomplete,
  };
};

export default useAiSummary;
